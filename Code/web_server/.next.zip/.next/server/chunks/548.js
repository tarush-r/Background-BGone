exports.id = 548;
exports.ids = [548];
exports.modules = {

/***/ 2548:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": function() { return /* binding */ AuthContextProvider; },
  "a": function() { return /* binding */ useAuth; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "firebase/auth"
var auth_ = __webpack_require__(5942);
// EXTERNAL MODULE: external "firebase/app"
var app_ = __webpack_require__(9421);
;// CONCATENATED MODULE: ./firebase/clientApp.ts
// import firebase from "firebase/app";
// import "firebase/auth";
// import "firebase/firestore";
// import "firebase/storage";
// // Import the functions you need from the SDKs you need


const clientCredentials = {
  apiKey: "AIzaSyAyEipM0cgYjCyZGhZF2cJewwWYf08IkRY",
  authDomain: "keystone-295p.firebaseapp.com",
  projectId: "keystone-295p",
  storageBucket: "keystone-295p.appspot.com",
  messagingSenderId: "578988953035",
  appId: "1:578988953035:web:a9bfb5e4a6d904d0f8fa4e",
  measurementId: "G-LES89K6YL1"
};
const app = (0,app_.initializeApp)(clientCredentials);
const auth = (0,auth_.getAuth)(); // if (!firebase.apps.length) {
//   firebase.initializeApp(clientCredentials);
// }
// export default firebase;
;// CONCATENATED MODULE: ./context/AuthContext.tsx





const AuthContext = /*#__PURE__*/(0,external_react_.createContext)({});
const useAuth = () => (0,external_react_.useContext)(AuthContext);
const AuthContextProvider = ({
  children
}) => {
  const {
    0: user,
    1: setUser
  } = (0,external_react_.useState)(null);
  const {
    0: loading,
    1: setLoading
  } = (0,external_react_.useState)(true);
  console.log(user);
  (0,external_react_.useEffect)(() => {
    const unsubscribe = (0,auth_.onAuthStateChanged)(auth, user => {
      if (user) {
        setUser({
          uid: user.uid,
          email: user.email,
          displayName: user.displayName
        });
      } else {
        setUser(null);
      }

      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const signup = (email, password) => {
    return (0,auth_.createUserWithEmailAndPassword)(auth, email, password);
  };

  const login = (email, password) => {
    return (0,auth_.signInWithEmailAndPassword)(auth, email, password);
  };

  const logout = async () => {
    setUser(null);
    await (0,auth_.signOut)(auth);
  };

  return /*#__PURE__*/jsx_runtime_.jsx(AuthContext.Provider, {
    value: {
      user,
      login,
      signup,
      logout
    },
    children: loading ? null : children
  });
};

/***/ })

};
;